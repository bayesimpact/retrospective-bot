#!/bin/bash

set -e

SHELL="/bin/bash" pipenv run "$@"
